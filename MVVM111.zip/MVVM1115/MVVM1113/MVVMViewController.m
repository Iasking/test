//
//  MVVMViewController.m
//  MVVM1113
//
//  Created by 漫步云端 on 2017/11/13.
//  Copyright © 2017年 漫步云端. All rights reserved.
//

#import "MVVMViewController.h"
#import "MVVMPaper.h"
#import "MVVMView.h"
#import "MVVMViewModel.h"

@interface MVVMViewController ()

@property(nonatomic,strong)MVVMPaper* paper;
@property(nonatomic,strong)MVVMView* mvvmView;
@property(nonatomic,strong)MVVMViewModel* viewModel;

@end

@implementation MVVMViewController

-(void)viewDidLoad
{
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    self.paper = [MVVMPaper new];
    _paper.content = @"点这儿";
    self.viewModel = [MVVMViewModel new];
    
    self.mvvmView = [MVVMView new];
    _mvvmView.frame = self.view.bounds;
    [self.view addSubview:_mvvmView];
    

    [_viewModel setWithModel:_paper];

    [_mvvmView setWithViewModel:_viewModel];

}

@end
