//
//  MVVMView.m
//  MVVM1113
//
//  Created by 漫步云端 on 2017/11/13.
//  Copyright © 2017年 漫步云端. All rights reserved.
//

#import "MVVMView.h"
#import "FBKVOController.h"
#import "NSObject+FBKVOController.h"

@interface MVVMView ()

@property(nonatomic,strong)UILabel* lblContent;

@property(nonatomic,strong)UIButton* btnPrint;
@property(nonatomic,strong)MVVMViewModel* viewModel;

@end
@implementation MVVMView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.lblContent = [UILabel new];
        [self addSubview:self.lblContent];
        self.lblContent.frame = CGRectMake(100, 100, 200, 30);
        self.lblContent.font = [UIFont systemFontOfSize:20];
        self.lblContent.textColor = [UIColor blackColor];
        
        self.btnPrint = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, 100, 50)];
        [self.btnPrint setTitle:@"按钮" forState:UIControlStateNormal];
        [self.btnPrint addTarget:self action:@selector(onPrintClick) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:self.btnPrint];
        
        
    }
    return self;
}

-(void)setWithViewModel:(MVVMViewModel *)vm
{
    //这句没有的话,会报错
    self.viewModel = vm;

    [self.KVOController observe:vm keyPath:@"contentStr" options:NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew block:^(id  _Nullable observer, id  _Nonnull object, NSDictionary<NSKeyValueChangeKey,id> * _Nonnull change) {
        NSString* newContent = change[NSKeyValueChangeNewKey];
        self.lblContent.text = newContent;
    }];
    
}


-(void)onPrintClick
{
    [self.viewModel onPrintClick];
    
}
@end
