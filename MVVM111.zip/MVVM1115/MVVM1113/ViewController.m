//
//  ViewController.m
//  MVVM1113
//
//  Created by 漫步云端 on 2017/11/13.
//  Copyright © 2017年 漫步云端. All rights reserved.
//

#import "ViewController.h"
#import "MVVMViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self showMVVM];
    });
    
}

-(void)showMVVM
{
    MVVMViewController* mvvmC = [MVVMViewController new];
    [self presentViewController:mvvmC animated:YES completion:nil];

    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
