//
//  MVVMPaper.h
//  MVVM1113
//
//  Created by 漫步云端 on 2017/11/13.
//  Copyright © 2017年 漫步云端. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MVVMPaper : NSObject

@property(nonatomic,strong)NSString* content;


@end
