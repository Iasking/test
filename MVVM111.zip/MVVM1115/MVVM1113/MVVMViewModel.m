//
//  MVVMViewModel.m
//  MVVM1113
//
//  Created by 漫步云端 on 2017/11/13.
//  Copyright © 2017年 漫步云端. All rights reserved.
//

#import "MVVMViewModel.h"
#import "FBKVOController.h"

@interface MVVMViewModel ()

@property(nonatomic,strong)MVVMPaper* model;

@end

@implementation MVVMViewModel



-(void)setWithModel:(MVVMPaper*)paper
{
    self.model = paper;
    
    self.contentStr = paper.content;
    
}

-(void)onPrintClick
{
    self.model.content = @"被你点过啦";
    self.contentStr = self.model.content;
    
}

@end
