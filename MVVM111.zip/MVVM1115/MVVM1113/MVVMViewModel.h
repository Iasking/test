//
//  MVVMViewModel.h
//  MVVM1113
//
//  Created by 漫步云端 on 2017/11/13.
//  Copyright © 2017年 漫步云端. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MVVMPaper.h"

@interface MVVMViewModel : NSObject

@property(nonatomic,strong)NSString* contentStr;

-(void)setWithModel:(MVVMPaper*)paper;

-(void)onPrintClick;

@end
